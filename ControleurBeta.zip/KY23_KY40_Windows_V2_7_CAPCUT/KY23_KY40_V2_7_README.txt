KY23/KY40 Windows Translator V2.7
====================================

Version Windows uniquement. Pas besoin de recharger le .ino si la version Serial V2.2 fonctionne deja sur le Teensy.

Installation dependances :
  py -m pip install pyserial pyautogui

Lancement :
  RUN_KY23_KY40_V2_7.bat

CAPCUT V2.7
-----------
Mapping demande :
- KY23 droite/gauche : fleche droite/gauche pour naviguer dans la timeline
- KY23 haut/bas : Ctrl + molette pour zoomer la timeline
- KY40 encodeur : molette seule pour monter/descendre dans la timeline
- pas de switch de mode CapCut
- aucun clic gauche envoye

FUSION 360
----------
Conserve le comportement Fusion precedent :
- KY23 : ORB / SHF
- KY40 : WHL / MID
- overlay haut-centre

AUTO PROFILE
------------
- AUTO detecte Fusion 360 ou CapCut selon le titre de fenetre active
- sinon OFF

Si AUTO ne detecte pas CapCut, choisir manuellement CAPCUT dans Profil logiciel.
