@echo off
title KY23/KY40 Translator V2.7
echo === KY23/KY40 Translator V2.7 ===
echo.
echo Si dependances manquantes :
echo   py -m pip install pyserial pyautogui
echo.
py "%~dp0KY23_KY40_Windows_Translator_V2_7.py"
echo.
echo Programme termine.
pause
