
"""
KY23_KY40_Windows_Translator_V2_7.py

Version Windows Serial -> souris/clavier.
- Teensy en USB Type = Serial uniquement.
- Aucune fonction HID directe dans le Teensy.
- Le clic gauche est interdit dans ce programme : aucun mouseDown/click/button="left".
- Reglages separes KY23 et KY40 dans l'interface.
- Overlay permanent tres discret en haut-centre : ORB/SHF + WHL/MID.
- KY40 peut envoyer chaque cran en "molette enfoncee" sans rester bloque.
- Filtre anti-tremblement KY40 reglable.
- Duree de maintien KY23 SW reglable = recentrage curseur au centre de l'ecran Windows.
- Clic court KY40 SW = bascule WHL/MID, sans envoyer de clic souris.
- Detection automatique Fusion 360 / CapCut par fenetre active.
- Profil CapCut V2.7 : KY23 X = fleches timeline, KY23 Y = Ctrl+molette zoom, KY40 = molette seule vertical timeline.

Installation :
  py -m pip install pyserial pyautogui

Lancement conseille : RUN_KY23_KY40_V2_7.bat
"""

import ctypes
import math
import queue
import sys
import threading
import time
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

try:
    import serial
    import serial.tools.list_ports
except Exception as exc:
    serial = None
    SERIAL_IMPORT_ERROR = exc
else:
    SERIAL_IMPORT_ERROR = None

try:
    import pyautogui
except Exception as exc:
    pyautogui = None
    PYAUTOGUI_IMPORT_ERROR = exc
else:
    PYAUTOGUI_IMPORT_ERROR = None

APP_VERSION = "V2.7"
BAUDRATE = 115200
READ_TIMEOUT = 0.05

# Reglages par defaut. Modifiables dans l'interface.
DEFAULT_DEADZONE = 80
DEFAULT_JOY_SPEED = 10.0       # baisse si KY23 trop rapide
DEFAULT_KY40_SCROLL_MULT = 6   # augmente si KY40 trop lent
DEFAULT_MAX_MOVE_PER_TICK = 14
DEFAULT_KY40_JITTER_MS = 45
DEFAULT_KY40_MIDDLE_HOLD_MS = 80
DEFAULT_JOY_LONG_PRESS_MS = 800
MAX_JOY_MAG = 470

MODE_ORBIT = "ORBIT_MIDDLE"
MODE_SHIFT_ORBIT = "SHIFT_MIDDLE"

PROFILE_AUTO = "AUTO"
PROFILE_FUSION = "FUSION"
PROFILE_CAPCUT = "CAPCUT"
PROFILE_OFF = "OFF"

PROFILE_LABELS = {
    PROFILE_AUTO: "Auto : Fusion / CapCut selon la fenetre active",
    PROFILE_FUSION: "Forcer Fusion 360",
    PROFILE_CAPCUT: "Forcer CapCut",
    PROFILE_OFF: "Off : detection seulement, aucune action",
}

KY40_MODE_WHEEL_ONLY = "WHEEL_ONLY"
KY40_MODE_MIDDLE_PER_NOTCH = "MIDDLE_PER_NOTCH"

KY40_MODE_LABELS = {
    KY40_MODE_WHEEL_ONLY: "KY40 = molette seule",
    KY40_MODE_MIDDLE_PER_NOTCH: "KY40 = clic molette maintenu pendant chaque cran",
}

MODE_LABELS = {
    MODE_ORBIT: "Joystick = clic molette + mouvement",
    MODE_SHIFT_ORBIT: "Joystick = Shift + clic molette + mouvement",
}


def log(msg):
    print(msg, flush=True)


class HidState:
    def __init__(self):
        self.physical_middle_down = False
        self.joy_middle_wanted = False
        self.ky40_middle_wanted = False
        self.shift_down = False

    def safe_call(self, func, *args, **kwargs):
        if pyautogui is None:
            return
        try:
            func(*args, **kwargs)
        except Exception as exc:
            log("Erreur pyautogui : " + repr(exc))
            traceback.print_exc()

    def sync_middle(self):
        wanted = self.joy_middle_wanted or self.ky40_middle_wanted
        if wanted and not self.physical_middle_down:
            self.safe_call(pyautogui.mouseDown, button="middle")
            self.physical_middle_down = True
        elif not wanted and self.physical_middle_down:
            self.safe_call(pyautogui.mouseUp, button="middle")
            self.physical_middle_down = False

    def release_all(self):
        if pyautogui is None:
            return
        self.joy_middle_wanted = False
        self.ky40_middle_wanted = False
        self.sync_middle()
        if self.shift_down:
            self.safe_call(pyautogui.keyUp, "shift")
        self.shift_down = False

    def set_shift(self, wanted: bool):
        if pyautogui is None:
            return
        if wanted and not self.shift_down:
            self.safe_call(pyautogui.keyDown, "shift")
            self.shift_down = True
        elif not wanted and self.shift_down:
            self.safe_call(pyautogui.keyUp, "shift")
            self.shift_down = False

    def set_middle(self, wanted: bool):
        self.joy_middle_wanted = wanted
        self.sync_middle()

    def set_ky40_middle(self, wanted: bool):
        self.ky40_middle_wanted = wanted
        self.sync_middle()


class SerialReader(threading.Thread):
    def __init__(self, port_name, output_queue, stop_event):
        super().__init__(daemon=True)
        self.port_name = port_name
        self.output_queue = output_queue
        self.stop_event = stop_event

    def run(self):
        if serial is None:
            self.output_queue.put(("error", f"pyserial manquant : {SERIAL_IMPORT_ERROR}"))
            return
        try:
            log(f"Ouverture du port {self.port_name} a {BAUDRATE}...")
            with serial.Serial(self.port_name, BAUDRATE, timeout=READ_TIMEOUT) as ser:
                time.sleep(0.2)
                self.output_queue.put(("status", f"Connecte a {self.port_name}"))
                while not self.stop_event.is_set():
                    raw = ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("ascii", errors="ignore").strip()
                    if line:
                        self.output_queue.put(("line", line))
        except Exception as exc:
            traceback.print_exc()
            self.output_queue.put(("error", repr(exc)))


class ModeOverlay:
    def __init__(self, parent):
        self.parent = parent
        self.win = None
        self.label = None
        self.current_text = "OFF | WHL"

    def show(self, text, duration_ms=None):
        # Overlay permanent, tres petit, en haut-centre de l'ecran.
        self.current_text = text
        if self.win is None or not self.win.winfo_exists():
            self.win = tk.Toplevel(self.parent)
            self.win.overrideredirect(True)
            self.win.attributes("-topmost", True)
            try:
                self.win.attributes("-alpha", 0.48)
            except Exception:
                pass
            self.label = tk.Label(
                self.win,
                text="",
                font=("Segoe UI", 10, "bold"),
                bg="#222222",
                fg="#f2f2f2",
                padx=8,
                pady=2,
            )
            self.label.pack()

        self.label.config(text=text)
        self.win.update_idletasks()
        sw = self.win.winfo_screenwidth()
        w = self.win.winfo_width()
        self.win.geometry(f"+{max(0, (sw - w) // 2)}+0")
        self.win.deiconify()
        self.win.lift()
        try:
            self.win.attributes("-topmost", True)
        except Exception:
            pass

    def hide(self):
        # On ne cache plus l'overlay automatiquement.
        if self.win is not None and self.win.winfo_exists():
            self.win.withdraw()


class TranslatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"KY23/KY40 Windows Translator {APP_VERSION}")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.q = queue.Queue()
        self.stop_event = threading.Event()
        self.reader = None
        self.hid = HidState()

        self.enabled = tk.BooleanVar(value=False)
        self.mode = tk.StringVar(value=MODE_ORBIT)
        self.profile_mode = tk.StringVar(value=PROFILE_AUTO)
        self.current_profile = PROFILE_OFF
        self.port = tk.StringVar(value="")
        self.status = tk.StringVar(value="Deconnecte")
        self.last_data = tk.StringVar(value="Aucune donnee")
        self.active_window = tk.StringVar(value="")

        self.deadzone = tk.IntVar(value=DEFAULT_DEADZONE)
        self.joy_speed = tk.DoubleVar(value=DEFAULT_JOY_SPEED)
        self.ky40_scroll_mult = tk.IntVar(value=DEFAULT_KY40_SCROLL_MULT)
        self.max_move = tk.IntVar(value=DEFAULT_MAX_MOVE_PER_TICK)
        self.ky40_button_middle_enabled = tk.BooleanVar(value=False)  # OFF par defaut pour eviter les clics accidentels
        self.ky40_wheel_mode = tk.StringVar(value=KY40_MODE_WHEEL_ONLY)
        self.ky40_jitter_ms = tk.IntVar(value=DEFAULT_KY40_JITTER_MS)
        self.ky40_middle_hold_ms = tk.IntVar(value=DEFAULT_KY40_MIDDLE_HOLD_MS)
        self.joy_long_press_ms = tk.IntVar(value=DEFAULT_JOY_LONG_PRESS_MS)
        self.ky40_debug_enabled = tk.BooleanVar(value=True)
        self.ky40_debug_lines = []
        self.ky40_last_debug = tk.StringVar(value="KY40 brut/filtre : -")

        self.joy_was_pressed = False
        self.joy_press_start = None
        self.joy_long_action_done = False
        self.last_mode_change = 0.0
        self.last_data_time = 0.0
        self.last_ky40_delta = 0
        self.last_ky40_time = 0.0
        self.ky40_middle_release_at = 0.0
        self.ky40_sw_was_pressed = False
        self.last_ky40_mode_change = 0.0
        self.last_capcut_x_time = 0.0
        self.last_capcut_zoom_time = 0.0
        self.overlay = ModeOverlay(self.root)

        self.build_ui()
        self.refresh_ports()
        self.update_overlay()
        self.tick()

    def build_ui(self):
        frm = ttk.Frame(self.root, padding=12)
        frm.grid(row=0, column=0, sticky="nsew")

        ttk.Label(frm, text="Port Teensy").grid(row=0, column=0, sticky="w")
        self.port_combo = ttk.Combobox(frm, textvariable=self.port, width=22, state="readonly")
        self.port_combo.grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Button(frm, text="Rafraichir", command=self.refresh_ports).grid(row=0, column=2, padx=3)
        ttk.Button(frm, text="Connecter", command=self.connect).grid(row=0, column=3, padx=3)

        ttk.Checkbutton(frm, text="Activer conversion souris/clavier", variable=self.enabled, command=self.on_enabled_change).grid(row=1, column=0, columnspan=4, sticky="w", pady=(10, 0))

        ttk.Label(frm, text="Profil logiciel").grid(row=2, column=0, sticky="w", pady=(10, 0))
        profile_combo = ttk.Combobox(frm, textvariable=self.profile_mode, width=42, state="readonly", values=list(PROFILE_LABELS.keys()))
        profile_combo.grid(row=2, column=1, columnspan=3, sticky="ew", padx=6, pady=(10, 0))

        ttk.Label(frm, text="Mode joystick KY23").grid(row=3, column=0, sticky="w", pady=(10, 0))
        mode_combo = ttk.Combobox(frm, textvariable=self.mode, width=42, state="readonly", values=list(MODE_LABELS.keys()))
        mode_combo.grid(row=3, column=1, columnspan=3, sticky="ew", padx=6, pady=(10, 0))

        settings = ttk.LabelFrame(frm, text="Reglages vitesse / securite", padding=8)
        settings.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        settings.columnconfigure(1, weight=1)

        ttk.Label(settings, text="KY23 vitesse").grid(row=0, column=0, sticky="w")
        ttk.Scale(settings, from_=1.0, to=30.0, orient="horizontal", variable=self.joy_speed).grid(row=0, column=1, sticky="ew", padx=8)
        ttk.Label(settings, textvariable=self.joy_speed, width=8).grid(row=0, column=2, sticky="e")

        ttk.Label(settings, text="KY40 molette x").grid(row=1, column=0, sticky="w")
        ttk.Spinbox(settings, from_=1, to=40, textvariable=self.ky40_scroll_mult, width=6).grid(row=1, column=1, sticky="w", padx=8)
        ttk.Label(settings, text="augmente si trop lent").grid(row=1, column=2, sticky="w")

        ttk.Label(settings, text="Deadzone KY23").grid(row=2, column=0, sticky="w")
        ttk.Spinbox(settings, from_=20, to=250, increment=5, textvariable=self.deadzone, width=6).grid(row=2, column=1, sticky="w", padx=8)
        ttk.Label(settings, text="augmente si ca bouge au centre").grid(row=2, column=2, sticky="w")

        ttk.Label(settings, text="Max mouvement/tick").grid(row=3, column=0, sticky="w")
        ttk.Spinbox(settings, from_=2, to=40, textvariable=self.max_move, width=6).grid(row=3, column=1, sticky="w", padx=8)

        ttk.Label(settings, text="KY40 mode cran").grid(row=4, column=0, sticky="w")
        ttk.Combobox(settings, textvariable=self.ky40_wheel_mode, width=36, state="readonly", values=list(KY40_MODE_LABELS.keys())).grid(row=4, column=1, columnspan=2, sticky="ew", padx=8, pady=(3, 0))

        ttk.Label(settings, text="KY40 anti-tremble ms").grid(row=5, column=0, sticky="w")
        ttk.Spinbox(settings, from_=0, to=200, increment=5, textvariable=self.ky40_jitter_ms, width=6).grid(row=5, column=1, sticky="w", padx=8)
        ttk.Label(settings, text="augmente si +1/-1 parasite").grid(row=5, column=2, sticky="w")

        ttk.Label(settings, text="KY40 maintien molette ms").grid(row=6, column=0, sticky="w")
        ttk.Spinbox(settings, from_=20, to=300, increment=10, textvariable=self.ky40_middle_hold_ms, width=6).grid(row=6, column=1, sticky="w", padx=8)

        ttk.Label(settings, text="Maintien KY23 centre ms").grid(row=7, column=0, sticky="w")
        ttk.Spinbox(settings, from_=250, to=3000, increment=50, textvariable=self.joy_long_press_ms, width=6).grid(row=7, column=1, sticky="w", padx=8)
        ttk.Label(settings, text="appui long SW = centre ecran").grid(row=7, column=2, sticky="w")

        ttk.Checkbutton(settings, text="Journal KY40 brut/filtre", variable=self.ky40_debug_enabled).grid(row=8, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(settings, text="KY40 SW : clic court = WHL / MID, aucun clic souris").grid(row=9, column=0, columnspan=3, sticky="w", pady=(6, 0))

        ttk.Button(frm, text="PANIC OFF", command=self.panic_off).grid(row=5, column=0, sticky="ew", pady=(12, 0))
        ttk.Button(frm, text="Relacher Shift + molette", command=self.hid.release_all).grid(row=5, column=1, sticky="ew", padx=6, pady=(12, 0))
        ttk.Button(frm, text="Centrer curseur", command=self.center_cursor).grid(row=5, column=2, sticky="ew", padx=6, pady=(12, 0))
        ttk.Button(frm, text="Afficher overlay", command=self.update_overlay).grid(row=5, column=3, sticky="ew", pady=(12, 0))

        ttk.Label(frm, textvariable=self.status).grid(row=6, column=0, columnspan=4, sticky="w", pady=(12, 0))
        ttk.Label(frm, textvariable=self.last_data).grid(row=7, column=0, columnspan=4, sticky="w")
        ttk.Label(frm, textvariable=self.active_window).grid(row=8, column=0, columnspan=4, sticky="w")
        ttk.Label(frm, textvariable=self.ky40_last_debug).grid(row=9, column=0, columnspan=4, sticky="w")
        self.ky40_log = tk.Text(frm, height=5, width=80)
        self.ky40_log.grid(row=10, column=0, columnspan=4, sticky="ew", pady=(4, 0))

        note = (
            "Aucun clic gauche n'est envoye par ce programme.\n"
            "KY23 : 2 modes seulement : molette / Shift+molette. Maintien SW 3s = centre ecran.\n"
            "KY40 : molette seule ou molette enfoncee par cran. Journal KY40 brut/filtre visible.\n"
            "Profil AUTO : Fusion 360 garde les controles actuels, CapCut V2.7 utilise X=fleches, Y=Ctrl+molette, KY40=molette seule."
        )
        ttk.Label(frm, text=note).grid(row=11, column=0, columnspan=4, sticky="w", pady=(12, 0))

        self.root.columnconfigure(0, weight=1)
        frm.columnconfigure(1, weight=1)

    def refresh_ports(self):
        if serial is None:
            messagebox.showerror("Module manquant", "Installe pyserial : py -m pip install pyserial")
            self.status.set(f"pyserial manquant : {SERIAL_IMPORT_ERROR}")
            return
        ports_info = list(serial.tools.list_ports.comports())
        ports = [p.device for p in ports_info]
        descriptions = [f"{p.device} - {p.description}" for p in ports_info]
        log("Ports detectes : " + (", ".join(descriptions) if descriptions else "aucun"))
        self.port_combo["values"] = ports
        if ports and not self.port.get():
            self.port.set(ports[0])
        self.status.set("Ports detectes : " + (", ".join(ports) if ports else "aucun"))

    def connect(self):
        if not self.port.get():
            messagebox.showwarning("Port manquant", "Choisis le port COM du Teensy.")
            return
        self.stop_event.set()
        self.hid.release_all()
        time.sleep(0.1)
        self.stop_event = threading.Event()
        self.reader = SerialReader(self.port.get(), self.q, self.stop_event)
        self.reader.start()

    def on_enabled_change(self):
        if not self.enabled.get():
            self.hid.release_all()
            self.update_overlay()
        else:
            self.update_overlay()

    def on_ky40_button_option(self):
        if not self.ky40_button_middle_enabled.get():
            self.hid.set_ky40_middle(False)

    def panic_off(self):
        self.enabled.set(False)
        self.hid.release_all()
        self.status.set("PANIC OFF : toutes les fonctions speciales relachees")

    def parse_data(self, line):
        parts = line.split(",")
        if len(parts) != 8 or parts[0] != "DATA":
            return None
        try:
            return {
                "raw_x": int(parts[1]),
                "raw_y": int(parts[2]),
                "dx": int(parts[3]),
                "dy": int(parts[4]),
                "joy_sw": int(parts[5]) == 1,
                "ky40_delta": int(parts[6]),
                "ky40_sw": int(parts[7]) == 1,
            }
        except ValueError:
            return None

    def overlay_text(self):
        ky40 = "MID" if self.ky40_wheel_mode.get() == KY40_MODE_MIDDLE_PER_NOTCH else "WHL"
        prof = self.current_profile
        if not self.enabled.get():
            return f"OFF | {ky40}"
        if prof == PROFILE_CAPCUT:
            return "CAP | SCR"
        if prof == PROFILE_FUSION:
            joy = "SHF" if self.mode.get() == MODE_SHIFT_ORBIT else "ORB"
            return f"{joy} | {ky40}"
        return f"??? | {ky40}"

    def update_overlay(self):
        self.show_overlay(self.overlay_text())

    def show_overlay(self, text):
        try:
            self.overlay.show(text)
        except Exception:
            traceback.print_exc()


    def add_ky40_debug(self, raw_delta, filtered_delta, action):
        if not self.ky40_debug_enabled.get():
            return
        if raw_delta == 0 and filtered_delta == 0:
            return
        msg = f"{time.strftime('%H:%M:%S')}  brut:{raw_delta:+d}  filtre:{filtered_delta:+d}  {action}"
        self.ky40_last_debug.set("KY40 brut/filtre : " + msg)
        try:
            self.ky40_log.insert("end", msg + "\n")
            self.ky40_log.see("end")
        except Exception:
            pass

    def center_cursor(self):
        try:
            # Centre de l'ecran principal Windows, pas centre du joystick.
            user32 = ctypes.windll.user32
            w = user32.GetSystemMetrics(0)
            h = user32.GetSystemMetrics(1)
            user32.SetCursorPos(w // 2, h // 2)
            self.status.set(f"Curseur recentre au centre ecran : {w // 2},{h // 2}")
            self.update_overlay()
        except Exception:
            traceback.print_exc()

    def handle_joy_button(self, pressed):
        now = time.time()
        if pressed and not self.joy_was_pressed:
            self.joy_press_start = now
            self.joy_long_action_done = False

        if pressed and self.joy_press_start is not None and not self.joy_long_action_done:
            if now - self.joy_press_start >= max(0.25, int(self.joy_long_press_ms.get()) / 1000.0):
                self.center_cursor()
                self.joy_long_action_done = True

        if (not pressed) and self.joy_was_pressed:
            duration = now - self.joy_press_start if self.joy_press_start is not None else 0
            if duration < max(0.25, int(self.joy_long_press_ms.get()) / 1000.0) and not self.joy_long_action_done and now - self.last_mode_change > 0.25:
                self.cycle_mode()
                self.last_mode_change = now
            self.joy_press_start = None
            self.joy_long_action_done = False

        self.joy_was_pressed = pressed

    def handle_line(self, line):
        if line.startswith("BOOT") or line.startswith("CENTER"):
            self.status.set(line)
            log(line)
            return
        data = self.parse_data(line)
        if data is None:
            return

        self.last_data_time = time.time()
        self.last_data.set(
            f"X:{data['raw_x']} Y:{data['raw_y']} dx:{data['dx']} dy:{data['dy']} "
            f"JoySW:{int(data['joy_sw'])} KY40:{data['ky40_delta']} KY40SW:{int(data['ky40_sw'])}"
        )

        self.handle_joy_button(data["joy_sw"])
        self.handle_ky40_button(data["ky40_sw"])

        if not self.enabled.get() or pyautogui is None:
            self.hid.release_all()
            return

        self.apply_controls(data)

    def cycle_mode(self):
        modes = [MODE_ORBIT, MODE_SHIFT_ORBIT]
        current = self.mode.get()
        idx = modes.index(current) if current in modes else 0
        self.mode.set(modes[(idx + 1) % len(modes)])
        self.hid.release_all()
        label = MODE_LABELS[self.mode.get()]
        self.status.set(f"Mode : {label}")
        self.update_overlay()

    def handle_ky40_button(self, pressed):
        now = time.time()
        if pressed and not self.ky40_sw_was_pressed and now - self.last_ky40_mode_change > 0.25:
            if self.ky40_wheel_mode.get() == KY40_MODE_MIDDLE_PER_NOTCH:
                self.ky40_wheel_mode.set(KY40_MODE_WHEEL_ONLY)
                self.hid.set_ky40_middle(False)
                self.ky40_middle_release_at = 0.0
                self.status.set("KY40 mode : WHL")
            else:
                self.ky40_wheel_mode.set(KY40_MODE_MIDDLE_PER_NOTCH)
                self.status.set("KY40 mode : MID")
            self.last_ky40_mode_change = now
            self.update_overlay()
        self.ky40_sw_was_pressed = pressed

    def apply_controls(self, data):
        profile = self.current_profile
        if profile == PROFILE_CAPCUT:
            self.apply_capcut_controls(data)
            return
        if profile != PROFILE_FUSION:
            self.hid.release_all()
            return

        dx = data["dx"]
        dy = data["dy"]
        deadzone = max(1, int(self.deadzone.get()))
        mag = math.sqrt(dx * dx + dy * dy)
        active = mag > deadzone

        raw_wheel = data["ky40_delta"]
        wheel = self.filter_ky40_delta(raw_wheel)
        action = "ignore" if raw_wheel and wheel == 0 else ""
        if wheel != 0:
            scroll_amount = int(wheel * max(1, int(self.ky40_scroll_mult.get())))
            try:
                if self.ky40_wheel_mode.get() == KY40_MODE_MIDDLE_PER_NOTCH:
                    # Demande clic molette juste avant la molette, puis relache automatiquement apres le delai.
                    # Le clic molette physique est gere comme un etat partage pour eviter les desynchros avec le KY23.
                    self.hid.set_ky40_middle(True)
                    self.ky40_middle_release_at = time.time() + max(0.02, int(self.ky40_middle_hold_ms.get()) / 1000.0)
                    action = "middle+wheel"
                else:
                    action = "wheel"
                pyautogui.scroll(scroll_amount)
            except Exception:
                traceback.print_exc()
        self.add_ky40_debug(raw_wheel, wheel, action)

        if self.ky40_middle_release_at and time.time() >= self.ky40_middle_release_at:
            self.hid.set_ky40_middle(False)
            self.ky40_middle_release_at = 0.0
        elif not self.ky40_middle_release_at:
            self.hid.set_ky40_middle(False)

        if not active:
            self.hid.set_middle(False)
            self.hid.set_shift(False)
            return

        mode = self.mode.get()
        want_shift = (mode == MODE_SHIFT_ORBIT)
        self.hid.set_shift(want_shift)
        self.hid.set_middle(True)

        # Courbe progressive : petite inclinaison = lent, grande inclinaison = plus rapide.
        # On retire la deadzone pour eviter le saut brutal au depart.
        effective_mag = min(MAX_JOY_MAG, max(0.0, mag - deadzone))
        strength = effective_mag / max(1.0, (MAX_JOY_MAG - deadzone))
        strength = max(0.0, min(1.0, strength))
        curved = strength * strength

        if mag == 0:
            ux = 0.0
            uy = 0.0
        else:
            ux = dx / mag
            uy = dy / mag

        speed = float(self.joy_speed.get())
        max_move = max(1, int(self.max_move.get()))
        move_x = int(max(-max_move, min(max_move, ux * curved * speed)))
        move_y = int(max(-max_move, min(max_move, uy * curved * speed)))

        # Garantit un mouvement continu meme avec petite inclinaison hors deadzone.
        if active and move_x == 0 and abs(dx) > abs(dy):
            move_x = 1 if dx > 0 else -1
        if active and move_y == 0 and abs(dy) >= abs(dx):
            move_y = 1 if dy > 0 else -1

        if move_x != 0 or move_y != 0:
            try:
                pyautogui.moveRel(move_x, move_y, duration=0)
            except Exception:
                traceback.print_exc()


    def apply_capcut_controls(self, data):
        # CapCut V2.7 : pas de clic souris, pas de mode a bascule.
        # KY23 X = fleche gauche/droite pour naviguer dans la timeline.
        # KY23 Y = Ctrl + molette pour zoomer la timeline.
        # KY40 = molette seule pour monter/descendre dans la timeline.
        self.hid.release_all()
        dx = data["dx"]
        dy = data["dy"]
        deadzone = max(1, int(self.deadzone.get()))
        now = time.time()

        # KY40 : molette seule, independante du mode WHL/MID utilise dans Fusion.
        raw_wheel = data["ky40_delta"]
        wheel = self.filter_ky40_delta(raw_wheel)
        action = "ignore" if raw_wheel and wheel == 0 else ""
        if wheel != 0:
            amount = int(wheel * max(1, int(self.ky40_scroll_mult.get())))
            try:
                pyautogui.scroll(amount)
                action = "capcut wheel"
            except Exception:
                traceback.print_exc()
        self.add_ky40_debug(raw_wheel, wheel, action)

        # KY23 X : navigation timeline par impulsions fleche gauche/droite.
        if abs(dx) > deadzone:
            strength_x = min(1.0, max(0.0, (abs(dx) - deadzone) / max(1.0, MAX_JOY_MAG - deadzone)))
            interval = 0.16 - (0.13 * strength_x)
            if now - self.last_capcut_x_time >= interval:
                key = "right" if dx > 0 else "left"
                repeats = 1 + int(strength_x * 3)
                try:
                    for _ in range(repeats):
                        pyautogui.press(key)
                except Exception:
                    traceback.print_exc()
                self.last_capcut_x_time = now

        # KY23 Y : zoom timeline via Ctrl + molette.
        if abs(dy) > deadzone:
            strength_y = min(1.0, max(0.0, (abs(dy) - deadzone) / max(1.0, MAX_JOY_MAG - deadzone)))
            interval = 0.18 - (0.14 * strength_y)
            if now - self.last_capcut_zoom_time >= interval:
                amount = 1 + int(strength_y * max(1, int(self.ky40_scroll_mult.get())))
                # Sens choisi pour correspondre a un joystick pousse vers le haut = zoom dans un sens.
                amount = -amount if dy > 0 else amount
                try:
                    pyautogui.keyDown("ctrl")
                    pyautogui.scroll(amount)
                    pyautogui.keyUp("ctrl")
                except Exception:
                    try:
                        pyautogui.keyUp("ctrl")
                    except Exception:
                        pass
                    traceback.print_exc()
                self.last_capcut_zoom_time = now

    def filter_ky40_delta(self, delta):
        if delta == 0:
            return 0
        now = time.time()
        jitter_s = max(0, int(self.ky40_jitter_ms.get())) / 1000.0
        if (
            self.last_ky40_delta != 0
            and delta == -self.last_ky40_delta
            and (now - self.last_ky40_time) < jitter_s
        ):
            self.last_ky40_delta = delta
            self.last_ky40_time = now
            return 0
        self.last_ky40_delta = delta
        self.last_ky40_time = now
        return delta


    def detect_profile_from_title(self, title):
        t = (title or "").lower()
        if "capcut" in t:
            return PROFILE_CAPCUT
        if "fusion 360" in t or "autodesk fusion" in t or "fusion" in t:
            return PROFILE_FUSION
        return PROFILE_OFF

    def effective_profile(self, title=None):
        requested = self.profile_mode.get()
        if requested == PROFILE_AUTO:
            return self.detect_profile_from_title(title if title is not None else self.get_foreground_title())
        return requested

    def get_foreground_title(self):
        try:
            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            length = user32.GetWindowTextLengthW(hwnd)
            buff = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buff, length + 1)
            return buff.value
        except Exception:
            return ""

    def tick(self):
        while True:
            try:
                kind, payload = self.q.get_nowait()
            except queue.Empty:
                break
            if kind == "line":
                self.handle_line(payload)
            elif kind == "status":
                self.status.set(payload)
                log(payload)
            elif kind == "error":
                self.status.set(f"Erreur : {payload}")
                log("Erreur : " + payload)
                self.enabled.set(False)
                self.hid.release_all()

        if self.enabled.get() and self.last_data_time and time.time() - self.last_data_time > 0.5:
            self.hid.release_all()
            self.ky40_middle_release_at = 0.0

        if self.ky40_middle_release_at and time.time() >= self.ky40_middle_release_at:
            self.hid.set_ky40_middle(False)
            self.ky40_middle_release_at = 0.0

        title = self.get_foreground_title()
        new_profile = self.effective_profile(title)
        if new_profile != self.current_profile:
            self.hid.release_all()
            self.current_profile = new_profile
            self.update_overlay()
        if title:
            prof_label = {PROFILE_FUSION: "FUSION", PROFILE_CAPCUT: "CAPCUT", PROFILE_OFF: "OFF"}.get(self.current_profile, "?")
            self.active_window.set(f"Profil actif : {prof_label} | Fenetre active : {title[:80]}")

        self.root.after(15, self.tick)

    def on_close(self):
        self.enabled.set(False)
        self.stop_event.set()
        self.hid.release_all()
        self.root.destroy()


def main():
    log("Demarrage KY23/KY40 Windows Translator " + APP_VERSION)
    log("Python : " + sys.version)
    if serial is None:
        log("pyserial manquant : " + repr(SERIAL_IMPORT_ERROR))
    if pyautogui is None:
        log("pyautogui manquant : " + repr(PYAUTOGUI_IMPORT_ERROR))

    if pyautogui is None:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Module manquant", "Installe pyautogui : py -m pip install pyautogui")
        return

    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0

    root = tk.Tk()
    TranslatorApp(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        input("\nERREUR. Appuie sur Entree pour fermer...")
