/*
  KY23_KY40_Serial_Controller_V2_2.ino

  Objectif V2.2 :
  - Teensy 4.1 NE FAIT PLUS souris/clavier.
  - Teensy envoie seulement l'état du joystick KY23 et du KY40 en USB Serial.
  - Le programme Windows convertit ensuite en souris/clavier.

  Cablage valide :
  KY23 VRx -> Teensy 4.1 pin 39
  KY23 VRy -> Teensy 4.1 pin 40
  KY23 SW  -> Teensy 4.1 pin 41
  KY23 VCC -> Teensy 4.1 3.3V
  KY23 GND -> Teensy 4.1 GND

  KY40 CLK -> Teensy 4.1 pin 30
  KY40 DT  -> Teensy 4.1 pin 31
  KY40 SW  -> Teensy 4.1 pin 32
  KY40 VCC -> Teensy 4.1 3.3V
  KY40 GND -> Teensy 4.1 GND

  Arduino IDE :
  Tools -> USB Type -> Serial

  Note stricte :
  - Toute fonction HID directe Teensy (Mouse/Keyboard) a été supprimée volontairement.
  - Ne pas réintroduire Mouse.h / Keyboard.h sans validation explicite.
*/

#include <Arduino.h>

const int PIN_JOY_X  = 39;
const int PIN_JOY_Y  = 40;
const int PIN_JOY_SW = 41;

const int PIN_KY40_CLK = 30;
const int PIN_KY40_DT  = 31;
const int PIN_KY40_SW  = 32;

const unsigned long SEND_INTERVAL_MS = 10;
const unsigned long PRINT_BOOT_MS = 1200;
const unsigned long BUTTON_DEBOUNCE_MS = 35;

int joyCenterX = 512;
int joyCenterY = 512;

int ky40LastCLK = HIGH;
int ky40DeltaAccum = 0;

bool joySwStable = false;
bool joySwLastRead = false;
unsigned long joySwLastChangeMs = 0;

bool ky40SwStable = false;
bool ky40SwLastRead = false;
unsigned long ky40SwLastChangeMs = 0;

unsigned long lastSendMs = 0;

void updateDebouncedButton(int pin, bool &stableState, bool &lastReadState, unsigned long &lastChangeMs) {
  bool readingPressed = (digitalRead(pin) == LOW);
  unsigned long now = millis();

  if (readingPressed != lastReadState) {
    lastReadState = readingPressed;
    lastChangeMs = now;
  }

  if ((now - lastChangeMs) >= BUTTON_DEBOUNCE_MS) {
    stableState = readingPressed;
  }
}

void calibrateJoystick() {
  long sumX = 0;
  long sumY = 0;
  const int samples = 80;

  for (int i = 0; i < samples; i++) {
    sumX += analogRead(PIN_JOY_X);
    sumY += analogRead(PIN_JOY_Y);
    delay(5);
  }

  joyCenterX = sumX / samples;
  joyCenterY = sumY / samples;
}

void updateKy40Encoder() {
  int clk = digitalRead(PIN_KY40_CLK);
  int dt  = digitalRead(PIN_KY40_DT);

  if (clk != ky40LastCLK) {
    if (clk == LOW) {
      if (dt == HIGH) {
        ky40DeltaAccum++;
      } else {
        ky40DeltaAccum--;
      }
    }
    ky40LastCLK = clk;
  }
}

void setup() {
  pinMode(PIN_JOY_SW, INPUT_PULLUP);
  pinMode(PIN_KY40_CLK, INPUT_PULLUP);
  pinMode(PIN_KY40_DT, INPUT_PULLUP);
  pinMode(PIN_KY40_SW, INPUT_PULLUP);

  Serial.begin(115200);
  delay(PRINT_BOOT_MS);

  calibrateJoystick();
  ky40LastCLK = digitalRead(PIN_KY40_CLK);

  Serial.println("BOOT,KY23_KY40_SERIAL_CONTROLLER,V2.2");
  Serial.print("CENTER,");
  Serial.print(joyCenterX);
  Serial.print(',');
  Serial.println(joyCenterY);
}

void loop() {
  updateKy40Encoder();
  updateDebouncedButton(PIN_JOY_SW, joySwStable, joySwLastRead, joySwLastChangeMs);
  updateDebouncedButton(PIN_KY40_SW, ky40SwStable, ky40SwLastRead, ky40SwLastChangeMs);

  unsigned long now = millis();
  if (now - lastSendMs < SEND_INTERVAL_MS) return;
  lastSendMs = now;

  int rawX = analogRead(PIN_JOY_X);
  int rawY = analogRead(PIN_JOY_Y);
  int dx = rawX - joyCenterX;
  int dy = rawY - joyCenterY;

  int ky40Delta = ky40DeltaAccum;
  ky40DeltaAccum = 0;

  Serial.print("DATA,");
  Serial.print(rawX);
  Serial.print(',');
  Serial.print(rawY);
  Serial.print(',');
  Serial.print(dx);
  Serial.print(',');
  Serial.print(dy);
  Serial.print(',');
  Serial.print(joySwStable ? 1 : 0);
  Serial.print(',');
  Serial.print(ky40Delta);
  Serial.print(',');
  Serial.println(ky40SwStable ? 1 : 0);
}
